<tbody class="divide-y divide-gray-200 bg-white">
{{$slot}}
</tbody>