<x-admin-layout>
    <h3 class="text-gray-700 text-3xl font-semibold">Upload Laporan</h3>

    <div class="mt-4">
        @include('intern.forms')
    </div>
</x-admin-layout>