import './bootstrap';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();

import 'alpinejs';

// console.log(location.href.substring(location.href.lastIndexOf('/') + 1));
